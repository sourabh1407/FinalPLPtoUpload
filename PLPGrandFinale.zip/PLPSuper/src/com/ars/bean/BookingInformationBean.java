package com.ars.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BOOKINGINFORMATION")
public class BookingInformationBean {

	@Id
	@Column(name = "Booking_id")
	private String bookingId;
	@Column(name = "cust_email")
	private String customerEmail;
	@Column(name = "no_of_passengers")
	private int numberOfPassengers;
	@Column(name = "class_type ")
	private String classType;
	@Column(name = "total_fare")
	private double totalFare;
	@Column(name = "seat_number")
	private String seatNumbers;
	@Column(name = "Credit_Card_info")
	private String creditCardInformation;
	@Column(name = "src_city")
	private String sourceCity;
	@Column(name = "dest_city")
	private String destinationCity;
	@Column(name = "flightno")
	private String flightNumber;

	public BookingInformationBean() {
		super();
	}

	public BookingInformationBean(String bookingId, String customerEmail,
			int numberOfPassengers, String classType, double totalFare,
			String seatNumbers, String creditCardInformation,
			String sourceCity, String destinationCity, String flightNumber) {
		super();
		this.bookingId = bookingId;
		this.customerEmail = customerEmail;
		this.numberOfPassengers = numberOfPassengers;
		this.classType = classType;
		this.totalFare = totalFare;
		this.seatNumbers = seatNumbers;
		this.creditCardInformation = creditCardInformation;
		this.sourceCity = sourceCity;
		this.destinationCity = destinationCity;
		this.flightNumber = flightNumber;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public int getNumberOfPassengers() {
		return numberOfPassengers;
	}

	public void setNumberOfPassengers(int numberOfPassengers) {
		this.numberOfPassengers = numberOfPassengers;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public double getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}

	public String getSeatNumbers() {
		return seatNumbers;
	}

	public void setSeatNumbers(String seatNumbers) {
		this.seatNumbers = seatNumbers;
	}

	public String getCreditCardInformation() {
		return creditCardInformation;
	}

	public void setCreditCardInformation(String creditCardInformation) {
		this.creditCardInformation = creditCardInformation;
	}

	public String getSourceCity() {
		return sourceCity;
	}

	public void setSourceCity(String sourceCity) {
		this.sourceCity = sourceCity;
	}

	public String getDestinationCity() {
		return destinationCity;
	}

	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	@Override
	public String toString() {
		return "bookingId = " + bookingId + " | customerEmail = "
				+ customerEmail + " | numberOfPassengers = "
				+ numberOfPassengers + " | classType = " + classType
				+ " | totalFare = " + totalFare + " | seatNumbers = "
				+ seatNumbers + " | creditCardInformation = "
				+ creditCardInformation + " | sourceCity = " + sourceCity
				+ " | destinationCity = " + destinationCity
				+ " | flightNumber = " + flightNumber + "";
	}

}
